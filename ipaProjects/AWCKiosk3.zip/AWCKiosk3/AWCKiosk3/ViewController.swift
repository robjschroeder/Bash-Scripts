//
//  ViewController.swift
//  AWCKiosk3
//
//  Created by Robert J Schroeder on 8/22/19.
//  Copyright © 2019 Arizona Western College. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func techSvcsButton(_ sender: Any) {
        performSegue(withIdentifier: "segueTechSvcs", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}
