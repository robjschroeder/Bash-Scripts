//
//  ContentView.swift
//  SDKiosk1
//
//  Created by Robert J Schroeder on 7/14/20.
//  Copyright © 2020 Arizona Western College. All rights reserved.
//

import SwiftUI


struct ContentView: View {
    @State private var pushed: Bool = false

    var body: some View {

        NavigationView {
            VStack {
                Button("Show Detail View") {
                    self.pushed.toggle()
                }

                NavigationLink(destination: Test(pushed: $pushed), isActive: $pushed) { EmptyView() }
            }.navigationBarTitle("title1")
        }
    }
}
struct Test: View {
    @Binding var pushed: Bool
    var body: some View {
        Text("Hello, World!")
            .navigationBarBackButtonHidden(true)
            .navigationBarItems(leading: BackButton(label: "Back") {
                self.pushed = false
            })
    }
}
struct BackButton: View {
    let label: String
    let closure: () -> ()

    var body: some View {
        Button(action: { self.closure() }) {
            HStack {
                Image(systemName: "chevron.left")
                Text(label)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        /*@START_MENU_TOKEN@*/Text("Hello, World!")/*@END_MENU_TOKEN@*/
    }
}
